import { useState, useEffect } from 'react'
import { Button } from '@/components/ui/button.jsx'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Badge } from '@/components/ui/badge.jsx'
import { Progress } from '@/components/ui/progress.jsx'
import { CheckCircle, XCircle, ExternalLink } from 'lucide-react'
import pcCastleLogo from './assets/pc-castle-logo.png'
import './App.css'

function shuffleArray(arr) {
  const a = arr.slice()
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1))
    ;[a[i], a[j]] = [a[j], a[i]]
  }
  return a
}

function buildRandomQuiz(bank, count = 10) {
  const sample = shuffleArray(bank).slice(0, count)
  return sample.map((q, idx) => {
    const optionIdx = q.correctIndex ?? q.correct ?? q['الإجابة'] ?? 0
    const indices = q.options.map((_, i) => i)
    const shuffledIdx = shuffleArray(indices)
    const shuffledOptions = shuffledIdx.map(i => q.options[i])
    const newCorrect = shuffledIdx.indexOf(optionIdx)
    return {
      id: idx, // 0..count-1 داخل هذه المحاولة فقط
      text: q.text,
      options: shuffledOptions,
      correct: newCorrect,
      difficulty: q.difficulty,
    }
  })
}

function App() {
  const [questionsBank, setQuestionsBank] = useState([]) // بنك الأسئلة من الملف
  const [questions, setQuestions] = useState([])         // 10 أسئلة عشوائية لكل محاولة
  const [currentQuestion, setCurrentQuestion] = useState(0)
  const [selectedAnswers, setSelectedAnswers] = useState({})
  const [showResults, setShowResults] = useState(false)
  const [score, setScore] = useState(0)
  const [timeLeft, setTimeLeft] = useState(120) // 2 دقائق
  const [quizStarted, setQuizStarted] = useState(false)
  const PASS_SCORE = 6

  // تحميل ملف الأسئلة (100 سؤال)
  useEffect(() => {
    async function loadQuestions() {
      try {
        const res = await fetch('/questions.json', { cache: 'no-store' })
        const data = await res.json()
        const raw = data['أسئلة'] || data.questions || []
        const bank = raw
          .filter(q => (q['السؤال'] || q.question) && (q['الخيارات'] || q.options))
          .map((q) => ({
            text: q['السؤال'] || q.question,
            options: q['الخيارات'] || q.options,
            correctIndex: q['الإجابة'] ?? q.correct ?? 0,
            difficulty: q['الصعوبة'] || q.difficulty || 'سهل',
          }))
        setQuestionsBank(bank)
      } catch (e) {
        console.error('فشل تحميل ملف الأسئلة:', e)
        setQuestionsBank([])
      }
    }
    loadQuestions()
  }, [])

  // المؤقت
  useEffect(() => {
    if (quizStarted && timeLeft > 0 && !showResults) {
      const timer = setTimeout(() => setTimeLeft(t => t - 1), 1000)
      return () => clearTimeout(timer)
    } else if (timeLeft === 0 && !showResults) {
      handleSubmitQuiz()
    }
  }, [timeLeft, quizStarted, showResults])

  const formatTime = (seconds) => {
    const mins = Math.floor(seconds / 60)
    const secs = seconds % 60
    return `${mins}:${secs.toString().padStart(2, '0')}`
  }

  const handleAnswerSelect = (questionId, answerIndex) => {
    setSelectedAnswers(prev => ({ ...prev, [questionId]: answerIndex }))
  }

  const handleNextQuestion = () => {
    if (currentQuestion < questions.length - 1) setCurrentQuestion(q => q + 1)
  }

  const handlePrevQuestion = () => {
    if (currentQuestion > 0) setCurrentQuestion(q => q - 1)
  }

  const handleSubmitQuiz = () => {
    let correctAnswers = 0
    questions.forEach(q => {
      if (selectedAnswers[q.id] === q.correct) correctAnswers++
    })
    setScore(correctAnswers)
    setShowResults(true)
  }

  const handleStartQuiz = () => {
    // إنشاء نموذج جديد من 10 أسئلة عشوائية في كل مرة يبدأ فيها الاختبار
    const quiz = buildRandomQuiz(questionsBank, 10)
    setQuestions(quiz)
    setSelectedAnswers({})
    setCurrentQuestion(0)
    setScore(0)
    setTimeLeft(300)
    setShowResults(false)
    setQuizStarted(true)
  }

  const handleDiscordRedirect = () => {
    // رابط النجاح (تفعيل)
    window.open('https://discord.gg/ZpE4Rmj7Wk', '_blank')
  }

  const handleSupportRedirect = () => {
    // تواصل معنا/إبلاغ عن مشكلة
    window.open('https://discord.gg/fJdksVSWy5', '_blank')
  }

  const progress = questions.length > 0 ? ((currentQuestion + 1) / questions.length) * 100 : 0

  if (!quizStarted) {
    return (
      <div className="gradient-bg min-h-screen flex items-center justify-center p-4">
        <div className="max-w-4xl mx-auto text-center">
          {/* Header */}
          <header className="mb-8">
            <nav className="flex justify-between items-center mb-8">
              <div className="flex items-center space-x-4">
                <img src={pcCastleLogo} alt="PC Castle" className="h-12 w-auto floating-animation" />
                <h1 className="text-2xl font-bold text-glow">PC Castle</h1>
              </div>
              <div className="flex space-x-4">
                <Button variant="outline" className="hover-glow" onClick={handleSupportRedirect}>
                  <ExternalLink className="w-4 h-4 mr-2" />
                  تواصل معنا
                </Button>
                <Button variant="outline" className="hover-glow" onClick={handleSupportRedirect}>
                  <ExternalLink className="w-4 h-4 mr-2" />
                  الإبلاغ عن مشكلة
                </Button>
              </div>
            </nav>
          </header>

          {/* Welcome Card */}
          <Card className="glow-effect card-hover max-w-2xl mx-auto">
            <CardHeader className="text-center">
              <div className="mx-auto mb-4">
                <img src={pcCastleLogo} alt="PC Castle" className="h-24 w-auto mx-auto pulse-animation" />
              </div>
              <CardTitle className="text-4xl font-bold text-glow mb-4">مرحباً بك في PC Castle</CardTitle>
              <p className="text-xl text-muted-foreground">اختبار التفعيل الإلكتروني لسيرفر الكمبيوتر</p>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="text-center space-y-4">
                <p className="text-lg">أجب على 10 أسئلة حول مكونات الكمبيوتر للحصول على التفعيل</p>
                <div className="flex justify-center space-x-8 text-sm text-muted-foreground">
                  <div className="flex items-center space-x-2">
                    <CheckCircle className="w-5 h-5 text-primary" />
                    <span>10 أسئلة</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <CheckCircle className="w-5 h-5 text-primary" />
                    <span>5 دقائق</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <CheckCircle className="w-5 h-5 text-primary" />
                    <span>النجاح من {PASS_SCORE}/10</span>
                  </div>
                </div>
              </div>
              <Button onClick={handleStartQuiz} disabled={questionsBank.length < 10} className="w-full text-lg py-6 hover-glow" size="lg">
                {questionsBank.length >= 10 ? 'ابدأ الاختبار' : 'جاري تحميل بنك الأسئلة...'}
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    )
  }

  if (showResults) {
    const passed = score >= PASS_SCORE
    return (
      <div className="gradient-bg min-h-screen flex items-center justify-center p-4">
        <Card className={`glow-effect max-w-2xl mx-auto ${passed ? 'success-animation' : ''}`}>
          <CardHeader className="text-center">
            <div className="mx-auto mb-4">
              {passed ? (
                <CheckCircle className="w-24 h-24 text-primary mx-auto pulse-animation" />
              ) : (
                <XCircle className="w-24 h-24 text-destructive mx-auto" />
              )}
            </div>
            <CardTitle className="text-3xl font-bold text-glow">
              {passed ? 'لقد اجتزت الاختبار مبروك!' : 'للأسف، لم تنجح'}
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-6 text-center">
            <div className="space-y-4">
              <p className="text-xl">نتيجتك: <span className="font-bold text-primary">{score}/10</span></p>
              <Progress value={(score / 10) * 100} className="w-full" />
              <p className="text-muted-foreground">{passed ? 'أحسنت! لديك معرفة جيدة بمكونات الكمبيوتر' : 'تحتاج إلى مراجعة معلوماتك حول مكونات الكمبيوتر'}</p>
            </div>
            {passed ? (
              <div className="space-y-4">
                <Badge variant="default" className="text-lg px-6 py-2">مؤهل للانضمام إلى السيرفر</Badge>
                <p className="text-md text-muted-foreground mt-4">
                  يرجى تصوير الاختبار عن طريق Win + Shift + S وفتح تكت في الديسكورد وإرفاق الصورة للتفعيل.
                </p>
                <Button onClick={handleDiscordRedirect} className="w-full text-lg py-6 hover-glow" size="lg">
                  لفتح تكت اضغط هنا
                </Button>
              </div>
            ) : (
              <div className="space-y-4">
                <Button onClick={() => window.location.reload()} variant="outline" className="w-full hover-glow">إعادة المحاولة</Button>
                <Button onClick={() => { setQuizStarted(false) }} variant="outline" className="w-full hover-glow">العودة للصفحة الرئيسية</Button>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    )
  }

  const question = questions[currentQuestion]

  return (
    <div className="gradient-bg min-h-screen p-4">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <header className="mb-8">
          <nav className="flex justify-between items-center mb-6">
            <div className="flex items-center space-x-4">
              <img src={pcCastleLogo} alt="PC Castle" className="h-10 w-auto" />
              <h1 className="text-xl font-bold text-glow">PC Castle</h1>
            </div>
            <div className="flex items-center space-x-4">
              <Badge variant="outline" className="text-lg px-4 py-2">الوقت المتبقي: {formatTime(timeLeft)}</Badge>
            </div>
          </nav>
          {/* Progress */}
          <div className="space-y-2">
            <div className="flex justify-between text-sm text-muted-foreground">
              <span>السؤال {currentQuestion + 1} من {questions.length}</span>
              <span>{Math.round(progress)}%</span>
            </div>
            <div className="w-full bg-muted rounded-full h-2">
              <div className="progress-bar rounded-full h-2 transition-all duration-300" style={{ width: `${progress}%` }} />
            </div>
          </div>
        </header>

        {/* Question Card */}
        <Card className="question-card mb-8">
          <CardHeader>
            <div className="flex items-center space-x-4 mb-4">
              <Badge variant="secondary" className="text-lg px-4 py-2">السؤال {currentQuestion + 1}</Badge>
            </div>
            <CardTitle className="text-2xl text-right leading-relaxed">{question.text}</CardTitle>
            <div className="mt-2 text-sm opacity-75 text-right">الصعوبة: {question.difficulty}</div>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {question.options.map((option, index) => (
                <button
                  key={index}
                  onClick={() => handleAnswerSelect(question.id, index)}
                  className={`option-button w-full p-4 rounded-lg text-right text-lg ${selectedAnswers[question.id] === index ? 'selected' : ''}`}
                >
                  <div className="flex items-center justify-between">
                    <div className="w-6 h-6 rounded-full border-2 border-current flex items-center justify-center">
                      {selectedAnswers[question.id] === index && (<div className="w-3 h-3 rounded-full bg-current" />)}
                    </div>
                    <span>{option}</span>
                  </div>
                </button>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Navigation */}
        <div className="flex justify-between items-center">
          <Button onClick={handlePrevQuestion} disabled={currentQuestion === 0} variant="outline" className="hover-glow">السؤال السابق</Button>
          <div className="flex space-x-4">
            {currentQuestion === questions.length - 1 ? (
              <Button onClick={handleSubmitQuiz} disabled={selectedAnswers[question.id] === undefined} className="hover-glow px-8">إنهاء الاختبار</Button>
            ) : (
              <Button onClick={handleNextQuestion} disabled={selectedAnswers[question.id] === undefined} className="hover-glow">السؤال التالي</Button>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}

export default App


